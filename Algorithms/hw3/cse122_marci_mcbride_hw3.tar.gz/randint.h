#ifndef RANDOM_H_
#define RANDOM_H_

int nrandint(int range);
void seed();

#endif
